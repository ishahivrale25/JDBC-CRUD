import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class TestInsert {
	public static void main(String[] args) throws Exception {

		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("Driver load");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/batch134", "root", "root");
		System.out.println("Connection done");
		Statement st = con.createStatement();
		String i1 = "insert into product values(11,'Watch')";
		String i2 = "insert into product values(12,'Calculator')";
		String i3 = "insert into product values(13,'Tv')";
		st.executeUpdate(i1);
		st.executeUpdate(i2);
		st.executeUpdate(i3);
		System.out.println("Record inserted......" + i1);
		System.out.println("Record inserted......" + i2);
		System.out.println("Record inserted......" + i3);
		 
	}
}