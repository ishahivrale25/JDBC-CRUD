import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class TestDelete {
	public static void main(String[] args) throws Exception {

		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("Driver load");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/batch134", "root", "root");
		System.out.println("Connection done");
		Statement st = con.createStatement();
		String del = "delete from product where pid = 12";
		st.executeUpdate(del);
		System.out.println("Record deleted......" + del);
		
	}
}