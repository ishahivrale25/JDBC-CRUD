import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class TestUpdate {
	public static void main(String[] args) throws Exception {

		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("Driver load");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/batch134", "root", "root");
		System.out.println("Connection done");
		Statement st = con.createStatement();
		String u1 = "update product set pnm='Fan' where pid=11";
		st.executeUpdate(u1);
		System.out.println("Record updated......" + u1);
		
	}
}