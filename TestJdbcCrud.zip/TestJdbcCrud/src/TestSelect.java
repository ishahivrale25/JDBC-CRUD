import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import com.mysql.jdbc.ResultSet;

public class TestSelect {
	public static void main(String ags[]) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("Driver load");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/batch134", "root", "root");
		System.out.println("Connection done");
		Statement st = con.createStatement();
		String select = "select * from product";
		java.sql.ResultSet rs = st.executeQuery(select);
		while (rs.next()) {
			System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getString(3));

		}
		con.close();

	}
}
